package com.rs.bean;

/**
 * @author gowthc
 *
 */
public class RechargePlanBean {
	private String planName;
	private int planAmount;
	
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public int getPlanAmount() {
		return planAmount;
	}
	public void setPlanAmount(int planAmount) {
		this.planAmount = planAmount;
	}
}
