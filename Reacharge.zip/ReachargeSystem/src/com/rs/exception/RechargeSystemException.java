package com.rs.exception;

/**
 * @author gowthc
 *
 */
public class RechargeSystemException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 732299364999888153L;
	
	public RechargeSystemException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
